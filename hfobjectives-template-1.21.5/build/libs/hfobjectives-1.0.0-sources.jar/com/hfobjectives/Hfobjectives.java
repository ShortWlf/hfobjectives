package com.hfobjectives;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityCombatEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import net.minecraft.class_7923;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class Hfobjectives implements ModInitializer {
	public static final String MOD_ID = "hfobjectives";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	// Configuration file path.
	private static final String CONFIG_PATH = "config/hfobjectives.json";
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	// Loaded objectives and text settings.
	private static final List<CustomObjective> objectivesConfig = new ArrayList<>();
	private static TextSettings textSettings;

	// Active objectives, keyed by player's UUID.
	private static final ConcurrentHashMap<UUID, ActiveObjective> activeObjectives = new ConcurrentHashMap<>();

	@Override
	public void onInitialize() {
		LOGGER.info("Initializing HF Objectives mod!");
		loadConfig();

		// Register commands.
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
			// /startobjective command.
			dispatcher.register(class_2170.method_9247("startobjective")
					.then(class_2170.method_9244("objectiveId", StringArgumentType.word())
							.executes(context -> {
								class_2168 source = context.getSource();
								class_3222 player;
								try {
									player = source.method_44023();
								} catch (Exception e) {
									source.method_9226(() -> class_2561.method_43470("This command can only be used by a player."), true);
									return 1;
								}
								String objectiveId = StringArgumentType.getString(context, "objectiveId");
								CustomObjective objective = getObjectiveById(objectiveId);
								if (objective == null) {
									source.method_9226(() -> class_2561.method_43470("Objective with ID '" + objectiveId + "' not found."), true);
									return 1;
								}
								if (activeObjectives.containsKey(player.method_5667())) {
									source.method_9226(() -> class_2561.method_43470("You already have an active objective!"), true);
									return 1;
								}

								String messageText = "Objective Started: " + objective.description();
								player.method_7353(class_2561.method_43470(messageText)
										.method_10862(class_2583.field_24360.method_10977(getObjectiveColor())), true);
								source.method_9226(() -> class_2561.method_43470(messageText)
										.method_10862(class_2583.field_24360.method_10977(getObjectiveColor())), true);

								ActiveObjective active = new ActiveObjective(objective, objective.timeLimit());
								active.initialHealth = player.method_6032();
								if ("mobkill".equalsIgnoreCase(objective.objectiveType())) {
									active.killCount = 0;
								}
								activeObjectives.put(player.method_5667(), active);
								return 1;
							})
					)
			);

			// /completeobjective command.
			dispatcher.register(class_2170.method_9247("completeobjective")
					.executes(context -> {
						class_2168 source = context.getSource();
						class_3222 player;
						try {
							player = source.method_44023();
						} catch (Exception e) {
							source.method_9226(() -> class_2561.method_43470("This command can only be used by a player."), true);
							return 1;
						}
						ActiveObjective active = activeObjectives.get(player.method_5667());
						if (active == null) {
							source.method_9226(() -> class_2561.method_43470("You don't have any active objective.")
									.method_10862(class_2583.field_24360.method_10977(getObjectiveColor())), true);
							return 1;
						}
						active.completed = true;
						activeObjectives.remove(player.method_5667());
						source.method_9226(() -> class_2561.method_43470("Objective Complete!")
								.method_10862(class_2583.field_24360.method_10977(getObjectiveColor())), true);
						return 1;
					})
			);

			// /randobj command.
			dispatcher.register(class_2170.method_9247("randobj")
					.executes(context -> {
						class_2168 source = context.getSource();
						class_3222 player;
						try {
							player = source.method_44023();
						} catch (Exception e) {
							source.method_9226(() -> class_2561.method_43470("This command can only be used by a player."), true);
							return 1;
						}
						if (activeObjectives.containsKey(player.method_5667())) {
							source.method_9226(() -> class_2561.method_43470("You already have an active objective!"), true);
							return 1;
						}
						if (objectivesConfig.isEmpty()) {
							source.method_9226(() -> class_2561.method_43470("No objectives available!"), true);
							return 1;
						}
						Random rand = new Random();
						CustomObjective objective = objectivesConfig.get(rand.nextInt(objectivesConfig.size()));
						String messageText = "Objective Started: " + objective.description();
						player.method_7353(class_2561.method_43470(messageText)
								.method_10862(class_2583.field_24360.method_10977(getObjectiveColor())), true);
						source.method_9226(() -> class_2561.method_43470(messageText)
								.method_10862(class_2583.field_24360.method_10977(getObjectiveColor())), true);
						ActiveObjective active = new ActiveObjective(objective, objective.timeLimit());
						active.initialHealth = player.method_6032();
						if ("mobkill".equalsIgnoreCase(objective.objectiveType())) {
							active.killCount = 0;
						}
						activeObjectives.put(player.method_5667(), active);
						return 1;
					})
			);

			// /hfreloadobjectives command.
			dispatcher.register(class_2170.method_9247("hfreloadobjectives")
					.requires(src -> src.method_9259(2))
					.executes(context -> {
						loadConfig();
						context.getSource().method_9226(() -> class_2561.method_43470("Objectives configuration reloaded.")
								.method_10862(class_2583.field_24360.method_10977(getObjectiveColor())), true);
						return 1;
					})
			);
		});

		// AFTER_KILLED event: for direct kills.
		ServerEntityCombatEvents.AFTER_KILLED_OTHER_ENTITY.register((world, killedEntity, killer) -> {
			if (killer instanceof class_3222) {
				class_3222 player = (class_3222) killer;
				ActiveObjective active = activeObjectives.get(player.method_5667());
				if (active != null && "mobkill".equalsIgnoreCase(active.objective.objectiveType())) {
					String target = active.objective.target().trim().toLowerCase();
					class_2960 killedEntityId = class_7923.field_41177.method_10221(killedEntity.method_5864());
					if (killedEntityId != null) {
						String idStr = killedEntityId.toString().trim().toLowerCase();
						LOGGER.info("AFTER_KILLED event: target=[{}], killedEntityId=[{}]", target, idStr);
						if (target.equals(idStr)) {
							active.killCount++;
							LOGGER.info("Incremented kill count (event): now {}", active.killCount);
						}
					}
				}
			}
		});

		// TICK event: update on-screen status and monitor objectives.
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			long now = System.currentTimeMillis();
			for (class_3222 player : server.method_3760().method_14571()) {
				ActiveObjective active = activeObjectives.get(player.method_5667());
				if (active != null && !active.completed) {
					// For dontgethit objectives, fail immediately if damage is detected.
					if ("dontgethit".equalsIgnoreCase(active.objective.objectiveType()) &&
							player.method_6032() < active.initialHealth) {
						active.completed = true;
						activeObjectives.remove(player.method_5667());
						killPlayer(player, server.method_3739());
						player.method_7353(class_2561.method_43470("Objective Failed: You took damage!")
								.method_10862(class_2583.field_24360.method_10977(getObjectiveColor())), true);
						continue;
					}

					// For mobkill objectives, monitor nearby mobs as a backup.
					if ("mobkill".equalsIgnoreCase(active.objective.objectiveType())) {
						double radius = 10.0D;
						class_3218 serverWorld = (class_3218) player.method_37908();
						class_238 box = new class_238(player.method_23317() - radius, player.method_23318() - radius, player.method_23321() - radius,
								player.method_23317() + radius, player.method_23318() + radius, player.method_23321() + radius);
						List<class_1297> nearbyEntities = serverWorld.method_8390(class_1297.class, box,
								entity -> !(entity instanceof class_3222));
						for (class_1297 entity : nearbyEntities) {
							class_2960 id = class_7923.field_41177.method_10221(entity.method_5864());
							if (id != null) {
								String idStr = id.toString().trim().toLowerCase();
								if (active.objective.target().trim().toLowerCase().equals(idStr)) {
									active.monitoredEntities.add(entity.method_5667());
								}
							}
						}
						// Check for monitored entities that no longer exist.
						List<UUID> monitoredCopy = new ArrayList<>(active.monitoredEntities);
						for (UUID uuid : monitoredCopy) {
							if (serverWorld.method_66347(uuid) == null) {
								active.killCount++;
								active.monitoredEntities.remove(uuid);
								LOGGER.info("Incremented kill count (monitoring): now {}", active.killCount);
							}
						}
					}

					int remainingSeconds = (int) Math.ceil((active.endTime - now) / 1000.0);
					if (remainingSeconds < 0) remainingSeconds = 0;

					// Build an on-screen status message.
					class_5250 message = class_2561.method_43470("");
					String type = active.objective.objectiveType().toLowerCase();
					if ("gather".equals(type)) {
						int currentCount = countItemInInventory(player, active.objective.target());
						message = message.method_10852(class_2561.method_43470("Objective: " + active.objective.description() + " | ")
										.method_10862(class_2583.field_24360.method_10977(getObjectiveColor())))
								.method_10852(class_2561.method_43470("Counter: " + currentCount + "/" + active.objective.amount() + " | ")
										.method_10862(class_2583.field_24360.method_10977(getObjectiveColor())))
								.method_10852(class_2561.method_43470("Time: " + remainingSeconds + "s")
										.method_10862(class_2583.field_24360.method_10977(getTimerColor())));
						if (currentCount >= active.objective.amount()) {
							active.completed = true;
							activeObjectives.remove(player.method_5667());
							message = class_2561.method_43470("Objective Complete!")
									.method_10862(class_2583.field_24360.method_10977(getObjectiveColor()));
						}
					} else if ("mobkill".equals(type)) {
						int currentKills = active.killCount;
						message = message.method_10852(class_2561.method_43470("Objective: " + active.objective.description() + " | ")
										.method_10862(class_2583.field_24360.method_10977(getObjectiveColor())))
								.method_10852(class_2561.method_43470("Kills: " + currentKills + "/" + active.objective.amount() + " | ")
										.method_10862(class_2583.field_24360.method_10977(getObjectiveColor())))
								.method_10852(class_2561.method_43470("Time: " + remainingSeconds + "s")
										.method_10862(class_2583.field_24360.method_10977(getTimerColor())));
						if (currentKills >= active.objective.amount()) {
							active.completed = true;
							activeObjectives.remove(player.method_5667());
							message = class_2561.method_43470("Objective Complete!")
									.method_10862(class_2583.field_24360.method_10977(getObjectiveColor()));
						}
					} else if ("dontgethit".equals(type)) {
						message = message.method_10852(class_2561.method_43470("Objective: " + active.objective.description() + " | ")
										.method_10862(class_2583.field_24360.method_10977(getObjectiveColor())))
								.method_10852(class_2561.method_43470("Time: " + remainingSeconds + "s")
										.method_10862(class_2583.field_24360.method_10977(getTimerColor())));
						if (remainingSeconds <= 0 && !active.completed) {
							active.completed = true;
							activeObjectives.remove(player.method_5667());
							message = class_2561.method_43470("Objective Complete!")
									.method_10862(class_2583.field_24360.method_10977(getObjectiveColor()));
						}
					} else if ("stand".equals(type)) { // New "stand" objective type.
						class_3218 serverWorld = (class_3218) player.method_37908();
						class_2338 pos = player.method_24515().method_10074(); // Block directly under the player.
						class_2960 currentBlockId = class_7923.field_41175.method_10221(serverWorld.method_8320(pos).method_26204());
						if (currentBlockId != null && currentBlockId.toString().trim().equalsIgnoreCase(active.objective.target().trim())) {
							active.standingTicks++;  // Increment tick count if standing on the correct block.
						} else {
							active.standingTicks = 0;  // Reset if player steps off.
						}
						int secondsStanding = active.standingTicks / 20; // Convert ticks to seconds.
						message = message.method_10852(class_2561.method_43470("Objective: " + active.objective.description() + " | ")
										.method_10862(class_2583.field_24360.method_10977(getObjectiveColor())))
								.method_10852(class_2561.method_43470("Standing: " + secondsStanding + "/" + active.objective.amount() + " sec | ")
										.method_10862(class_2583.field_24360.method_10977(getObjectiveColor())))
								.method_10852(class_2561.method_43470("Time: " + remainingSeconds + "s")
										.method_10862(class_2583.field_24360.method_10977(getTimerColor())));
						if (secondsStanding >= active.objective.amount()) {
							active.completed = true;
							activeObjectives.remove(player.method_5667());
							message = class_2561.method_43470("Objective Complete!")
									.method_10862(class_2583.field_24360.method_10977(getObjectiveColor()));
						}
					} else {
						message = message.method_10852(class_2561.method_43470("Objective: " + active.objective.description() + " | ")
										.method_10862(class_2583.field_24360.method_10977(getObjectiveColor())))
								.method_10852(class_2561.method_43470("Time: " + remainingSeconds + "s")
										.method_10862(class_2583.field_24360.method_10977(getTimerColor())));
					}
					// Display the unified status message on the action bar.
					player.method_7353(message, true);
					if (!"dontgethit".equals(type) && remainingSeconds <= 0 && !active.completed) {
						active.completed = true;
						activeObjectives.remove(player.method_5667());
						killPlayer(player, server.method_3739());
						player.method_7353(class_2561.method_43470("Objective Failed!")
								.method_10862(class_2583.field_24360.method_10977(getObjectiveColor())), true);
					}
				}
			}
		});
	}

	/**
	 * Helper method to execute the kill command on the given player.
	 */
	private void killPlayer(class_3222 player, class_2168 source) {
		try {
			source.method_9211().method_3734().method_9235().execute(
					"kill @p[name=" + player.method_7334().getName() + "]", source);
		} catch (CommandSyntaxException e) {
			LOGGER.error("Error executing kill command: ", e);
		}
	}

	/**
	 * Helper method to count a specified item in a player's inventory.
	 */
	private int countItemInInventory(class_3222 player, String itemIdString) {
		int count = 0;
		class_2960 identifier = class_2960.method_12829(itemIdString);
		if (identifier == null) return 0;
		class_1792 targetItem = class_7923.field_41178.method_63535(identifier);
		for (class_1799 stack : player.method_31548()) {
			if (stack.method_7909() == targetItem) {
				count += stack.method_7947();
			}
		}
		return count;
	}

	/**
	 * Loads the mod's configuration from the file.
	 */
	private static void loadConfig() {
		File configFile = new File(CONFIG_PATH);
		if (!configFile.exists()) {
			LOGGER.info("Config not found. Creating default config.");
			createDefaultConfig(configFile);
		}
		try (FileReader reader = new FileReader(configFile)) {
			Type configType = new TypeToken<ModConfig>() {}.getType();
			ModConfig modConfig = GSON.fromJson(reader, configType);
			objectivesConfig.clear();
			if (modConfig.objectives() != null) {
				objectivesConfig.addAll(modConfig.objectives());
			}
			textSettings = modConfig.textSettings();
			LOGGER.info("Loaded {} objectives, text settings: objectiveColor={}, timerColor={}",
					objectivesConfig.size(), textSettings.objectiveColor(), textSettings.timerColor());
		} catch (IOException e) {
			LOGGER.error("Error loading config", e);
		}
	}

	/**
	 * Creates the default configuration file.
	 */
	private static void createDefaultConfig(File configFile) {
		try {
			File parent = configFile.getParentFile();
			if (!parent.exists() && !parent.mkdirs()) {
				LOGGER.error("Failed to create config directory!");
				return;
			}
			List<CustomObjective> defaults = new ArrayList<>();
			defaults.add(new CustomObjective("gatherdirt", "Gather dirt", 30, "gather", "minecraft:dirt", 1));
			defaults.add(new CustomObjective("gatherstone", "Collect stone", 45, "gather", "minecraft:stone", 5));
			defaults.add(new CustomObjective("collectarrows", "Collect at least 10 arrows", 30, "gather", "minecraft:arrow", 10));
			defaults.add(new CustomObjective("mobkillzombie", "Eliminate 3 zombies", 60, "mobkill", "minecraft:zombie", 3));
			defaults.add(new CustomObjective("dontgethitchallenge", "Survive without damage", 60, "dontgethit", "", 0));
			// New "stand" objective: stand on a gold block for 5 seconds.
			defaults.add(new CustomObjective("standongold", "Stand on a gold block for 5 seconds", 30, "stand", "minecraft:gold_block", 5));

			TextSettings defaultText = new TextSettings("green", "red");
			ModConfig defaultConfig = new ModConfig(defaultText, defaults);

			try (FileWriter writer = new FileWriter(configFile)) {
				GSON.toJson(defaultConfig, writer);
				LOGGER.info("Default config created at {}", CONFIG_PATH);
			}
		} catch (IOException e) {
			LOGGER.error("Error creating default config", e);
		}
	}

	/**
	 * Retrieves an objective by its ID.
	 */
	private static CustomObjective getObjectiveById(String id) {
		for (CustomObjective obj : objectivesConfig) {
			if (obj.id().equalsIgnoreCase(id)) {
				return obj;
			}
		}
		return null;
	}

	/**
	 * Returns the configured objective color as a Formatting value.
	 */
	private static class_124 getObjectiveColor() {
		try {
			return class_124.valueOf(textSettings.objectiveColor().toUpperCase());
		} catch (IllegalArgumentException e) {
			return class_124.field_1060;
		}
	}

	/**
	 * Returns the configured timer color as a Formatting value.
	 */
	private static class_124 getTimerColor() {
		try {
			return class_124.valueOf(textSettings.timerColor().toUpperCase());
		} catch (IllegalArgumentException e) {
			return class_124.field_1061;
		}
	}

	// --- Configuration Records ---

	/**
	 * The mod configuration record which contains text settings and objectives.
	 */
	public record ModConfig(TextSettings textSettings, List<CustomObjective> objectives) { }

	/**
	 * Text settings for the mod.
	 * objectiveColor: used for objective messages (default bright green).
	 * timerColor: used for timer messages (default red).
	 */
	public record TextSettings(String objectiveColor, String timerColor) { }

	/**
	 * Record representing a custom objective.
	 */
	public record CustomObjective(
			String id,
			String description,
			int timeLimit,
			String objectiveType,  // "gather", "manual", "mobkill", "dontgethit", "stand"
			String target,         // e.g. "minecraft:dirt", "minecraft:zombie", "minecraft:gold_block" for 'stand'
			int amount             // required count for 'gather'/'mobkill' or required seconds for 'stand'
	) { }

	/**
	 * Holds state for an active objective assigned to a player.
	 * For mobkill objectives, monitoredEntities tracks nearby entities by UUID.
	 */
	private static class ActiveObjective {
		public final CustomObjective objective;
		public boolean completed;
		public final long startTime;
		public final long endTime;
		public float initialHealth;
		public int killCount;
		public int standingTicks; // Tracks tick count for "stand" objectives.
		public final HashSet<UUID> monitoredEntities = new HashSet<>();

		public ActiveObjective(CustomObjective objective, int timeLimit) {
			this.objective = objective;
			this.completed = false;
			this.startTime = System.currentTimeMillis();
			this.endTime = this.startTime + timeLimit * 1000L;
			this.initialHealth = 0.0F;
			this.killCount = 0;
			this.standingTicks = 0;
		}
	}
}
